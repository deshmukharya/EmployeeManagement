//
//  Student+CoreDataClass.swift
//  Employee
//
//  Created by E5000861 on 17/06/24.
//
//

import Foundation
import CoreData

@objc(Student)
public class Student: NSManagedObject {

}
