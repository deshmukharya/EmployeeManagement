//
//  Student+CoreDataProperties.swift
//  Employee
//
//  Created by E5000861 on 17/06/24.
//
//

import Foundation
import CoreData


extension Student {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Student> {
        return NSFetchRequest<Student>(entityName: "Student")
    }

    @NSManaged public var name: String?
    @NSManaged public var id: String?
    @NSManaged public var email: String?

}

extension Student : Identifiable {

}
